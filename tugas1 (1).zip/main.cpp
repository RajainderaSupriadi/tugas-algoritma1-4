/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a, b;
    
    cout << "masukan bilangan ganjil: ";
    cin >> a;
    
    cout << "masukan bilangan genap: ";
    cin >> b;
    
    if(a % 2!= 0 && b % 2 ==0){
      cout << endl << "benar, ini bilangan ganjil dan genap"<< endl;  
    }else {
        cout << "dia bukan bilangan ganjil dan genap" << endl;
    }

    return 0;
}

