/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int pilihan;
    int jumlahbanyakTiket;
    int hargaEkonomi = 100000;
    int hargaBisnis = 200000;
    int hargaEksekutif = 300000;
    int totalHarga;

    cout << "Pilihhan jenis tiket:" << endl;
    cout << "1. Ekonomi (Rp.100,000/tiket)" << endl;
    cout << "2. Bisnis (Rp.200,000/tiket)" << endl;
    cout << "3. Eksekutif (Rp.300,000/tiket)" << endl;
    cout << "Masukkan pilihan (1-3): ";
    cin >> pilihan;

    cout << "Masukkan jumlah banyak tiket yang ingin dipesan: ";
    cin >> jumlahbanyakTiket;

    switch (pilihan) {
        case 1:
            totalHarga = jumlahbanyakTiket * hargaEkonomi;
            break;
        case 2:
            totalHarga = jumlahbanyakTiket * hargaBisnis;
            break;
        case 3:
            totalHarga = jumlahbanyakTiket * hargaEksekutif;
            break;
        default:
            cout << "Pilihan tidak ada di dalam pilihan menu" << endl;
            return 1;  
    }

    // diskon 
    if (totalHarga > 500000) {
        totalHarga *= 0.9;  // Potongan 10%
    } else if (totalHarga > 300000) {
        totalHarga *= 0.95;  // Potongan 5%
    } else if (totalHarga > 200000) {
        totalHarga *= 0.98;  // Potongan 2%
    }

    cout << "Total harga tiket: Rp" << totalHarga << endl;

   

    return 0;
}

