/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class Character {
public:
    string name;
    int health;
    int maxHealth;
    int attackPoints;
    int lootingPoints;
    int level;
    int specialAbilityCooldown;
    int specialAbilityDamage;

    Character(string n, int h, int ap, int lvl, int cooldown, int abilityDamage)
        : name(n), health(h), maxHealth(h), attackPoints(ap), lootingPoints(0), level(lvl),
          specialAbilityCooldown(cooldown), specialAbilityDamage(abilityDamage) {}

    void attack(Character& target) {
        cout << name << " menyerang " << target.name << " dan mengurangi " << attackPoints << " poin kesehatan.\n";
        target.receiveDamage(attackPoints);
    }

    void receiveDamage(int damage) {
        cout << name << " terkena serangan dan kehilangan " << damage << " poin kesehatan.\n";
        health -= damage;
    }

    void heal() {
        cout << name << " memulihkan diri dan menambah 10 poin kesehatan.\n";
        health += 10;
        if (health > maxHealth) {
            health = maxHealth;
        }
    }

    void loot() {
        cout << name << " sedang melakukan looting dan mendapatkan beberapa barang!\n";
        lootingPoints += 1;
    }

    void levelUp() {
        level += 1;
        maxHealth += 20;
        health = maxHealth;
        attackPoints += 5;
        cout << name << " naik level menjadi " << level << "!\n";
    }

    void useSpecialAbility(Character& target) {
        if (specialAbilityCooldown <= 0) {
            cout << name << " menggunakan kemampuan khusus dan mengurangi " << specialAbilityDamage << " poin kesehatan.\n";
            target.receiveDamage(specialAbilityDamage);
            specialAbilityCooldown = 3;
        } else {
            cout << name << " sedang dalam cooldown. Kemampuan khusus dapat digunakan dalam " << specialAbilityCooldown << " putaran lagi.\n";
        }
    }

    void reduceCooldown() {
        if (specialAbilityCooldown > 0) {
            specialAbilityCooldown--;
        }
    }
};

class Weapon {
public:
    string name;
    int damage;

    Weapon(string n, int d) : name(n), damage(d) {}
};

class Enemy : public Character {
public:
    Enemy(string n, int h) : Character(n, h, 0, 0, 0, 0) {}
};

int main() {
    string namaPemain;
    int Login;

    cout << "Masukkan Nama Pemain: ";
    getline(cin, namaPemain);

    cout << "WELCOME TO EPEP BURIK" << endl;
    cout << "========================" << endl;

    cout << "Pilih Login:" << endl;
    cout << "1. Facebook " << endl;
    cout << "2. Google " << endl;
    cout << "3. Guest" << endl;
    cout << "Masukkan pilihan (1-3): ";
    cin >> Login;

    Character sigitrendang("sigit rendang", 100, 20, 1, 0, 30);
    Character sumanto("sumanto", 80, 15, 1, 0, 25);
    Character tukangngendog("tukangngendog", 120, 10, 1, 0, 20);

    Weapon AK47Draco("AK47Draco", 30);
    Weapon Pedang("Pedang", 25);

    int choice;

    while (true) {
        cout << "Pilih karakter:\n";
        cout << "1. sigitrendang\n";
        cout << "2. sumanto\n";
        cout << "3. tukangngendog\n";
        cout << "4. Keluar\n";

        cin >> choice;

        if (choice == 4) {
            cout << "Terima kasih sudah bermain!\n";
            break;
        }

        Character* selectedCharacter;

        switch (choice) {
        case 1:
            selectedCharacter = &sigitrendang;
            break;
        case 2:
            selectedCharacter = &sumanto;
            break;
        case 3:
            selectedCharacter = &tukangngendog;
            break;
        default:
            cout << "Pilihan tidak valid. Silakan pilih lagi.\n";
            continue;
        }

        Enemy musuh("Bocil Kematian", 50);

        while (selectedCharacter->health > 0) {
            selectedCharacter->reduceCooldown();
            musuh.receiveDamage(selectedCharacter->attackPoints);

            cout << "Aksi yang tersedia:\n";
            cout << "1. Serang musuh \n";
            cout << "2. Memulihkan (+10pts)\n";
            cout << "3. Gunakan Kemampuan Khusus\n";
            cout << "4. Beli senjata\n";
            cout << "5. Loot peti mayat\n";
            cout << "6. Kembali\n";

            cin >> choice;

            switch (choice) {
            case 1:
                selectedCharacter->attack(musuh);
                break;
            case 2:
                selectedCharacter->heal();
                break;
            case 3:
                selectedCharacter->useSpecialAbility(musuh);
                break;
            case 4:
                cout << "List Senjata:\n";
                cout << "1. AK47Draco ⸝່ࠡࠣ᠊߯᠆ᡁࠣ࠘᠊᠊ࠢ࠘~~~(30 damage)\n";
                cout << "2. Katana ▬▬ι═══════ﺤ(25 damage)\n";
                cout << "Pilih senjata yang ingin dibeli:\n";

                cin >> choice;

                Weapon* selectedWeapon;

                switch (choice) {
                case 1:
                    selectedWeapon = &AK47Draco;
                    break;
                case 2:
                    selectedWeapon = &Pedang;
                    break;
                default:
                    cout << "Pilihan tidak valid. Silakan pilih lagi.\n";
                    continue;
                }

                cout << "Anda telah membeli " << selectedWeapon->name << "!\n";
                selectedCharacter->attackPoints += selectedWeapon->damage;
                break;
            case 5:
                selectedCharacter->loot();
                break;
            case 6:
                break;
            default:
                cout << "Pilihan tidak valid. Silakan pilih lagi.\n";
                continue;
            }

            if (musuh.health <= 0) {
                cout << "Musuh berhasil dikalahkan!\n";
                selectedCharacter->lootingPoints += 1;
                break;
            }

            musuh.receiveDamage(selectedCharacter->attackPoints);

            if (selectedCharacter->health <= 0) {
                cout << "Anda kalah. Game over!\n";
                break;
            }

            if (selectedCharacter->lootingPoints >= 5) {
                selectedCharacter->lootingPoints -= 5;
                selectedCharacter->levelUp();
            }

            cout << "Status karakter:\n";
            cout << "Nama: " << selectedCharacter->name << "\n";
            cout << "Level: " << selectedCharacter->level << "\n";
            cout << "Kesehatan: " << selectedCharacter->health << "\n";
            cout << "Poin Serangan: " << selectedCharacter->attackPoints << "\n";
            cout << "Poin Looting: " << selectedCharacter->lootingPoints << "\n";
        }
    }

    return 0;
}
